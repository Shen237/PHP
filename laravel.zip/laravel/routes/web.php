<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','IndexController@index');
Route::get('user/add','UserController@add');
Route::get('user/index','UserController@index');
Route::get('login','LoginController@index');
Route::get('user/index2','UserController@index');
Route::get('user/edit/{id}','UserController@edit');
Route::get('user/delete/{id}','UserController@delete');
Route::post('user/new','UserController@new');
Route::post('user/deleteall','UserController@deleteall');
Route::post('user/upd','UserController@upd');
Route::post('dologin','LoginController@dologin');
