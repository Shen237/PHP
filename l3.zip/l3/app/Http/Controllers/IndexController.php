<?php

namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;

class IndexController extends Controller
{
	
    public function index(){

    $data=User::paginate(4);
      return view('index.index',['data'=>$data]);
   
   	
   }
  
}
