<?php

namespace App\Http\Controllers;
use App\Users;
use Illuminate\Http\Request;

class LoginController extends Controller
{
	public $url='http://localhost/la/laravel/public';
    public function index(){

   		return view('login.index');
   }
   public function dologin(Request $request){
   		$data=$request->all();
   		
    	$user=Users::where('username',$data['username'])->first();
    	
    	if(empty($user)){
    			  echo "<script>alert('Account does not exist');</script>";
			  echo "<script>location.href='{$this->url}/login'</script>";
    	}
    	if($user->password != $request['password']){
    		 
    		     echo "<script>alert('Wrong password');</script>";
			  echo "<script>location.href='{$this->url}/login'</script>";
    	}

    	   echo "<script>alert('success');</script>";
			  echo "<script>location.href='{$this->url}/user/index'</script>";

   }
}
