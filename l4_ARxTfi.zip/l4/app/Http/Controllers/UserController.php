<?php
namespace App\Http\Controllers;
use App\User;
use App\Users;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class UserController extends Controller
{
	public $url='';
	 public function index(Request $request){
	     
	   
	    if(empty($request->session()->get('key2'))){
	         echo "<script>alert('Plasse login');</script>";
			  echo "<script>location.href='{$this->url}/login'</script>";
	    }
	 	$data=User::paginate(4);
   		return view('user.index',['data'=>$data]);
   }
    public function index2(){
	 	$data=User::get();
   		return view('user.2s',['data'=>$data]);
   }
   public function add(){
   		return view('user.add');
   }
    public function checkin(Request $request){
        $u=$request->session()->get('key2');
         return view('user.checkin',['data'=>$u]);
   }
    public function edit($id){
    	$data=User::find($id);
   		return view('user.edit',['data'=>$data]);
   }

   public function new(Request $request){
   		$input=$request->all();
   		$input=$request->except('_token');
   		$a=rand(1,26);
   		$input['status']=substr('adcdsaergaerjioqwenjhuivasdfweewekjrnlkjasdu',$a,6);
   		
   	   $res=User::create($input);
   	   if($res){
   	   	return redirect('user/index');
   	   }else{
   	   	 return back();
   	   }
   }

   public function upd(Request $request){
   		$input=$request->all();
   		/*$input=$request->except('_token');*/
   		$u=[
   			'title'=>$input['title'],
   			'content'=>$input['content'],
   			'fen'=>$input['fen'],
   			'semester'=>$input['semester'],
   			'teacher'=>$input['teacher'],
   			'times'=>$input['times'],
   		];
   	  $res=DB::table("stclass")->where('id',$input['id'])->update($u);
   	   if($res){
   	   	return redirect('user/index');
   	   }else{
   	   	 return back();
   	   }
   }

    public function delete($id){
   		
   	  $res=DB::table("stclass")->where('id',$id)->delete();
   	   if($res){
   	   	return redirect('user/index');
   	   }else{
   	   	 return back();
   	   }
   }

  

    public function deleteall(Request $request){
    	$input=$request->except('_token');
   		foreach ($input['id'] as  $v) {
   		 $res=DB::table("stclass")->where('id',$v)->delete();
   		}
   	 
   	   if($res){
   	   	return redirect('user/index');
   	   }else{
   	   	 return back();
   	   }
   }
 public function doin(Request $request){
   		$data=$request->all();
   	
    	$user=Users::where('username',$data['username'])->first();
    	
    	if(empty($user)){
    			  echo "<script>alert('no user');</script>";
			  echo "<script>location.href='{$this->url}/user/index'</script>";die;
    	}
    	if($user->password != $request['password']){
    		   
    		     echo "<script>alert('Wrong password');</script>";
			  echo "<script>location.href='{$this->url}/user/index'</script>";die;
    	}
         	$in=User::where('status',$data['title'])->first();
         	if(empty($in)){
         	     echo "<script>alert('invitation false');</script>";
			  echo "<script>location.href='{$this->url}/user/index'</script>";die;
         	}
         		$u=[
   			'lid'=>'verified',
   			
   		];
   	  $res=DB::table("stclass")->where('id',$in['id'])->update($u);
    	   echo "<script>alert('check in success');</script>";
			  echo "<script>location.href='{$this->url}/user/wel/{$data['username']}'</script>";

   }
   public function wel($id){
      
       	return view('user.wel',['data'=>$id]);
   }
    public function logout(Request $request){
           $request->session()->put('key2','');
      echo "<script>alert('logout success');</script>";
			  echo "<script>location.href='{$this->url}/login'</script>";
       	
   }

}
