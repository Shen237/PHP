<?php

namespace App\Http\Controllers;
use App\Users;
use Illuminate\Http\Request;

class LoginController extends Controller
{
	public $url='';
    public function index(){

   		return view('login.index');
   }
   public function dore(Request $request){
       	$data=$request->all();
       	if(strlen($data['username'])<6){
   		     echo "<script>alert('username < 6');</script>";
			  echo "<script>location.href='{$this->url}/register'</script>";
   		}
   			if(strlen($data['password'])<6){
   		     echo "<script>alert('username < 6');</script>";
			  echo "<script>location.href='{$this->url}/register'</script>";
   		}
   	
   		$input=$request->except('_token');
   		if($data['password']!=$data['qpassword']){
   		      echo "<script>alert('The password is inconsistent with the confirmation password');</script>";
			  echo "<script>location.href='{$this->url}/register'</script>";
   		}
    	$user=Users::where('username',$data['username'])->first();
       
    	if(!empty($user)){
    			  echo "<script>alert('The account has been registered');</script>";
			  echo "<script>location.href='{$this->url}/register'</script>";
    	}
    	 unset($input['qpassword']);
        unset($input['email']);
    	  $res=Users::create($input);
         
    	   echo "<script>alert('success');</script>";
			  echo "<script>location.href='{$this->url}/login'</script>";

   }
    public function dologin(Request $request){
   		$data=$request->all();
   	
    	$user=Users::where('username',$data['username'])->first();
    	
    	if(empty($user)){
    			  echo "<script>alert('Account does not exist');</script>";
			  echo "<script>location.href='{$this->url}/login'</script>";
    	}
    	if($user->password != $request['password']){
    		   
    		     echo "<script>alert('Wrong password');</script>";
			  echo "<script>location.href='{$this->url}/login'</script>";
    	}
          $request->session()->put('key2',$data['username']);
    	   echo "<script>alert('success');</script>";
			  echo "<script>location.href='{$this->url}/user/index'</script>";

   }
     public function register(){

   		return view('login.register');
   }
   
}
